# AI Powered Smart Student Assistant Chatbot System

A full-stack AI chatbot for college students. Ask programming doubts, subject
questions, get study & career guidance — with per-user saved chat history and
a feedback module.

Built on the Lovable stack: **React (TanStack Start / Vite) + TanStack Server
Functions ("backend REST-like API") + Lovable Cloud (PostgreSQL, Auth) + Lovable
AI Gateway (Google Gemini)**.

> The original spec called for Flask + MongoDB. This project uses the Lovable
> equivalents so it runs end-to-end in the preview. See "Architecture mapping"
> below for the direct spec ↔ implementation mapping to include in your report.

---

## 1. Project structure

```
.
├── src/
│   ├── routes/                     # File-based routes (pages)
│   │   ├── __root.tsx              # Root layout + SEO meta
│   │   ├── index.tsx               # Landing page
│   │   ├── auth.tsx                # Login + Register (tabs)
│   │   └── _authenticated/         # Requires signed-in user
│   │       ├── route.tsx           # Auth gate + sidebar
│   │       ├── dashboard.tsx       # Student dashboard
│   │       ├── chat.tsx            # Chat layout (chat list)
│   │       ├── chat.index.tsx      # Empty chat state
│   │       ├── chat.$chatId.tsx    # Chat window
│   │       ├── feedback.tsx        # Feedback form + history
│   │       └── profile.tsx         # Student profile
│   ├── lib/                        # "Backend" — server functions (REST-like API)
│   │   ├── ai-gateway.server.ts    # Lovable AI Gateway provider
│   │   ├── chat.functions.ts       # POST /chat → AI reply
│   │   ├── chats.functions.ts      # list/create/get/delete chats
│   │   └── profile.functions.ts    # profile + feedback
│   ├── integrations/supabase/      # Auto-generated Cloud client
│   └── styles.css                  # Design system tokens
├── supabase/migrations/            # Database schema (SQL)
├── public/robots.txt
├── docs/README.md                  # ← you are here
└── package.json
```

### Architecture mapping (spec → this project)

| Spec requirement                    | Implementation                                                       |
| ----------------------------------- | -------------------------------------------------------------------- |
| Frontend (React + Vite)             | React 19 + TanStack Start (Vite 7) under `src/routes/`               |
| Backend (Flask REST API)            | TanStack `createServerFn` handlers in `src/lib/*.functions.ts`       |
| Database (MongoDB Atlas)            | Managed PostgreSQL (Lovable Cloud) via SQL migrations                |
| Collections users/chats/feedback    | Tables `profiles`, `chats`, `messages`, `feedback`                   |
| Authentication                      | Cloud email/password auth + auto-created profile trigger             |
| AI chatbot                          | Google Gemini via Lovable AI Gateway (modular — model id swappable)  |
| Chat history                        | `chats` + `messages` tables, scoped by RLS to the signed-in user     |
| Feedback system                     | `feedback` table + `/feedback` page                                  |
| Error handling                      | Toasts (sonner) + typed error messages from server functions         |
| Responsive design                   | Tailwind v4, mobile-first, sidebar collapses on small screens        |

---

## 2. Installation & running

Prerequisites: **Node.js 20+** and **bun** (or npm).

```bash
bun install
bun run dev            # start dev server
bun run build          # production build
bun run preview        # preview production build
```

No separate backend process — TanStack Start hosts the React app and server
functions in one worker.

---

## 3. Environment variables

The `.env` file is auto-created when Lovable Cloud is enabled — do not edit
manually.

| Variable                        | Purpose                                       |
| ------------------------------- | --------------------------------------------- |
| `VITE_SUPABASE_URL`             | Public Cloud URL for the browser client       |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | Public anon key for the browser client        |
| `SUPABASE_URL`                  | Server-side URL for server functions          |
| `SUPABASE_PUBLISHABLE_KEY`      | Server-side anon key                          |
| `SUPABASE_SERVICE_ROLE_KEY`     | Server-only privileged key (managed)          |
| `LOVABLE_API_KEY`               | Lovable AI Gateway key (managed)              |

---

## 4. Database (ER explanation)

```
auth.users (managed by Cloud/Auth)
   │ 1
   │ 1
 profiles(id PK/FK, full_name, college, course, year, email)

auth.users 1───∞ chats(id PK, user_id FK, title, timestamps)
                    │ 1
                    │ ∞
                messages(id PK, chat_id FK, user_id FK, role, content, created_at)

auth.users 1───∞ feedback(id PK, user_id FK, rating 1-5, comment, created_at)
```

- Every user in `auth.users` has exactly one `profiles` row (auto-created on
  signup via a database trigger).
- A user can own many `chats`. Each chat has many `messages` (role: `user`,
  `assistant`, or `system`).
- `feedback` is a 1-to-many list of ratings + comments per user.
- **Row-Level Security (RLS)** enforces that every user can only read/write
  their own rows — the database does the filtering, not the app code.

---

## 5. API documentation

All "endpoints" are TanStack server functions (typed RPC, JSON in/out). All
require an authenticated session.

| Function            | File                              | Input                                     | Output                    |
| ------------------- | --------------------------------- | ----------------------------------------- | ------------------------- |
| `listChats`         | `lib/chats.functions.ts`          | –                                         | `Chat[]`                  |
| `createChat`        | `lib/chats.functions.ts`          | –                                         | `{ id }`                  |
| `getChatMessages`   | `lib/chats.functions.ts`          | `{ chatId }`                              | `{ chat, messages[] }`    |
| `deleteChat`        | `lib/chats.functions.ts`          | `{ chatId }`                              | `{ ok }`                  |
| `sendChatMessage`   | `lib/chat.functions.ts`           | `{ chatId, message }`                     | `{ assistant }`           |
| `getProfile`        | `lib/profile.functions.ts`        | –                                         | `Profile`                 |
| `updateProfile`     | `lib/profile.functions.ts`        | `{ full_name?, college?, course?, year? }`| `{ ok }`                  |
| `submitFeedback`    | `lib/profile.functions.ts`        | `{ rating (1-5), comment? }`              | `{ ok }`                  |
| `listMyFeedback`    | `lib/profile.functions.ts`        | –                                         | `Feedback[]`              |

### Chatbot logic (`src/lib/chat.functions.ts`)

1. Verify the chat belongs to the signed-in user.
2. Insert the user message into `messages`.
3. Load full message history for the chat.
4. Send `{ system prompt } + history` to `google/gemini-3-flash-preview` via
   the Lovable AI Gateway.
5. Insert the assistant reply into `messages`.
6. Auto-title the chat from the first user message.

The system prompt lives at the top of the file and scopes the AI to
**programming, subject, study, and career** guidance. To swap models, change
the string passed to `gateway(...)`.

---

## 6. Features checklist

- [x] Registration & login (email + password)
- [x] Student profile (name, college, course, year)
- [x] AI chatbot with markdown & code-block rendering
- [x] Persistent chat history (list / open / delete)
- [x] Feedback system (1–5 stars + comment)
- [x] Row-level security — each student only sees their own data
- [x] Responsive design (mobile nav + desktop sidebar)
- [x] Error handling via toasts and typed server-function errors

---

## 7. For your report

**Project architecture (one-liner):** a single-page React app calls typed
server functions on the same origin; those functions read/write PostgreSQL
(Lovable Cloud) and forward student questions to a Google Gemini model via the
Lovable AI Gateway. All data access is protected by Row-Level Security so a
signed-in student can only see their own data.

**Extending to another AI model:** edit `src/lib/chat.functions.ts` — change
the model id passed to `gateway(...)`, or plug in another OpenAI-compatible
provider. Auth, DB, and history flow stay unchanged.
