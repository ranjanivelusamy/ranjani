import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { GraduationCap, MessageSquare, BookOpen, Sparkles, Rocket } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-secondary/40 to-background">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <div className="flex items-center gap-2 font-bold text-lg">
          <GraduationCap className="h-6 w-6 text-primary" />
          <span>Smart Student Assistant</span>
        </div>
        <nav className="flex items-center gap-2">
          <Link to="/auth">
            <Button variant="ghost">Sign in</Button>
          </Link>
          <Link to="/auth">
            <Button>Get started</Button>
          </Link>
        </nav>
      </header>

      <main className="mx-auto max-w-6xl px-6 pt-12 pb-24">
        <section className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 rounded-full border bg-card px-3 py-1 text-xs text-muted-foreground mb-6">
            <Sparkles className="h-3.5 w-3.5 text-primary" /> AI-powered study buddy
          </div>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight leading-tight">
            Your AI Smart Student <span className="text-primary">Assistant</span>
          </h1>
          <p className="mt-6 text-lg text-muted-foreground">
            Ask programming doubts, subject questions, study strategies, and career guidance — all in one clean
            chat. Save conversations, revisit them anytime, and share feedback to keep improving.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/auth">
              <Button size="lg" className="gap-2">
                <Rocket className="h-4 w-4" /> Start chatting free
              </Button>
            </Link>
          </div>
        </section>

        <section className="mt-20 grid gap-6 md:grid-cols-3">
          {[
            {
              icon: MessageSquare,
              title: "Instant AI chat",
              desc: "Get clear explanations, code samples, and step-by-step help powered by modern AI.",
            },
            {
              icon: BookOpen,
              title: "Study & career",
              desc: "Plan study sessions, prepare for exams, and get advice on internships and careers.",
            },
            {
              icon: GraduationCap,
              title: "Your history",
              desc: "All chats are securely saved to your account so you can pick up right where you left off.",
            },
          ].map(({ icon: Icon, title, desc }) => (
            <div key={title} className="rounded-xl border bg-card p-6 shadow-sm">
              <Icon className="h-8 w-8 text-primary mb-3" />
              <h3 className="font-semibold text-lg mb-1">{title}</h3>
              <p className="text-sm text-muted-foreground">{desc}</p>
            </div>
          ))}
        </section>
      </main>

      <footer className="border-t py-6 text-center text-xs text-muted-foreground">
        Built for students · A college project by you
      </footer>
    </div>
  );
}
