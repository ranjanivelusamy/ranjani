import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getProfile, updateProfile } from "@/lib/profile.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/profile")({
  component: ProfilePage,
  head: () => ({ meta: [{ title: "Profile — Smart Student Assistant" }] }),
});

function ProfilePage() {
  const qc = useQueryClient();
  const getFn = useServerFn(getProfile);
  const updateFn = useServerFn(updateProfile);
  const { data } = useQuery({ queryKey: ["profile"], queryFn: () => getFn() });
  const [form, setForm] = useState({ full_name: "", college: "", course: "", year: "" });

  useEffect(() => {
    if (data) {
      setForm({
        full_name: data.full_name ?? "",
        college: data.college ?? "",
        course: data.course ?? "",
        year: data.year ?? "",
      });
    }
  }, [data]);

  const mutation = useMutation({
    mutationFn: () => updateFn({ data: form }),
    onSuccess: () => {
      toast.success("Profile updated");
      qc.invalidateQueries({ queryKey: ["profile"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="p-6 md:p-10 max-w-xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Your profile</h1>
        <p className="text-muted-foreground mt-1">{data?.email}</p>
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          mutation.mutate();
        }}
        className="rounded-xl border bg-card p-6 space-y-4"
      >
        <Field label="Full name" value={form.full_name} onChange={(v) => setForm({ ...form, full_name: v })} />
        <Field label="College / University" value={form.college} onChange={(v) => setForm({ ...form, college: v })} />
        <Field label="Course" value={form.course} onChange={(v) => setForm({ ...form, course: v })} />
        <Field label="Year" value={form.year} onChange={(v) => setForm({ ...form, year: v })} placeholder="e.g. 2nd year" />
        <Button type="submit" disabled={mutation.isPending}>
          {mutation.isPending ? "Saving…" : "Save changes"}
        </Button>
      </form>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <div>
      <Label>{label}</Label>
      <Input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="mt-1.5" />
    </div>
  );
}