import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { submitFeedback, listMyFeedback } from "@/lib/profile.functions";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Star } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/feedback")({
  component: FeedbackPage,
  head: () => ({ meta: [{ title: "Feedback — Smart Student Assistant" }] }),
});

function FeedbackPage() {
  const qc = useQueryClient();
  const submit = useServerFn(submitFeedback);
  const listFn = useServerFn(listMyFeedback);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");

  const { data: items } = useQuery({ queryKey: ["feedback"], queryFn: () => listFn() });

  const mutation = useMutation({
    mutationFn: () => submit({ data: { rating, comment: comment.trim() || undefined } }),
    onSuccess: () => {
      toast.success("Thanks for your feedback!");
      setComment("");
      setRating(5);
      qc.invalidateQueries({ queryKey: ["feedback"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="p-6 md:p-10 max-w-2xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Feedback</h1>
        <p className="text-muted-foreground mt-1">Help us improve your student assistant.</p>
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          mutation.mutate();
        }}
        className="rounded-xl border bg-card p-6 space-y-4"
      >
        <div>
          <label className="text-sm font-medium">Your rating</label>
          <div className="flex gap-1 mt-2">
            {[1, 2, 3, 4, 5].map((n) => (
              <button
                type="button"
                key={n}
                onClick={() => setRating(n)}
                className="p-1"
                aria-label={`${n} stars`}
              >
                <Star
                  className={`h-7 w-7 ${
                    n <= rating ? "fill-primary text-primary" : "text-muted-foreground"
                  }`}
                />
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="text-sm font-medium">Comment (optional)</label>
          <Textarea
            className="mt-2"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="What worked well? What could be better?"
            rows={4}
          />
        </div>
        <Button type="submit" disabled={mutation.isPending}>
          {mutation.isPending ? "Sending…" : "Submit feedback"}
        </Button>
      </form>

      <div>
        <h2 className="text-lg font-semibold mb-3">Your past feedback</h2>
        <div className="space-y-3">
          {(items ?? []).length === 0 && (
            <p className="text-sm text-muted-foreground">No feedback submitted yet.</p>
          )}
          {(items ?? []).map((f) => (
            <div key={f.id} className="rounded-lg border bg-card p-4">
              <div className="flex items-center gap-1 mb-1">
                {Array.from({ length: f.rating }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                ))}
              </div>
              {f.comment && <p className="text-sm">{f.comment}</p>}
              <p className="text-xs text-muted-foreground mt-2">
                {new Date(f.created_at).toLocaleString()}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}