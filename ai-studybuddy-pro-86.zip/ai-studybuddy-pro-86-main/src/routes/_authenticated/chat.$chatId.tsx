import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getChatMessages } from "@/lib/chats.functions";
import { sendChatMessage } from "@/lib/chat.functions";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send, GraduationCap, User } from "lucide-react";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";

export const Route = createFileRoute("/_authenticated/chat/$chatId")({
  component: ChatWindow,
});

function ChatWindow() {
  const { chatId } = Route.useParams();
  const qc = useQueryClient();
  const getMsgs = useServerFn(getChatMessages);
  const send = useServerFn(sendChatMessage);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["chat", chatId],
    queryFn: () => getMsgs({ data: { chatId } }),
  });

  const mutation = useMutation({
    mutationFn: (message: string) => send({ data: { chatId, message } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["chat", chatId] });
      qc.invalidateQueries({ queryKey: ["chats"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [data?.messages.length, mutation.isPending]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const text = input.trim();
    if (!text || mutation.isPending) return;
    setInput("");
    mutation.mutate(text);
  };

  return (
    <div className="flex flex-col h-full">
      <header className="border-b bg-card px-4 py-3">
        <h1 className="font-semibold truncate">{data?.chat.title ?? "Chat"}</h1>
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto p-4 md:p-6 space-y-6">
          {isLoading && <p className="text-sm text-muted-foreground">Loading…</p>}
          {data?.messages.length === 0 && (
            <div className="text-center text-muted-foreground py-16">
              <GraduationCap className="h-10 w-10 mx-auto text-primary mb-3" />
              <p>Ask your first question below.</p>
            </div>
          )}
          {data?.messages.map((m) => (
            <MessageBubble key={m.id} role={m.role} content={m.content} />
          ))}
          {mutation.isPending && <MessageBubble role="assistant" content="_Thinking..._" />}
        </div>
      </div>

      <form onSubmit={submit} className="border-t bg-card p-3">
        <div className="max-w-3xl mx-auto flex gap-2 items-end">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask a programming, subject, study or career question…"
            className="min-h-[52px] max-h-40 resize-none"
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                submit(e as unknown as React.FormEvent);
              }
            }}
          />
          <Button type="submit" size="icon" className="h-[52px] w-[52px]" disabled={mutation.isPending || !input.trim()}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </form>
    </div>
  );
}

function MessageBubble({ role, content }: { role: string; content: string }) {
  const isUser = role === "user";
  return (
    <div className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}>
      <div
        className={`h-8 w-8 rounded-full grid place-items-center shrink-0 ${
          isUser ? "bg-primary text-primary-foreground" : "bg-accent text-accent-foreground"
        }`}
      >
        {isUser ? <User className="h-4 w-4" /> : <GraduationCap className="h-4 w-4" />}
      </div>
      <div
        className={`rounded-2xl px-4 py-3 max-w-[85%] ${
          isUser ? "bg-primary text-primary-foreground" : "bg-card border"
        }`}
      >
        <div className="prose prose-sm max-w-none [&_pre]:bg-secondary [&_pre]:text-secondary-foreground [&_pre]:p-3 [&_pre]:rounded-md [&_pre]:overflow-x-auto [&_code]:text-sm">
          <ReactMarkdown>{content}</ReactMarkdown>
        </div>
      </div>
    </div>
  );
}