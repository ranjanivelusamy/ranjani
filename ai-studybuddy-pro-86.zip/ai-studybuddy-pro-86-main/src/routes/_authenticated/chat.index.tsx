import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { createChat } from "@/lib/chats.functions";
import { Button } from "@/components/ui/button";
import { MessageSquare, Plus } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/chat/")({
  component: ChatEmpty,
});

function ChatEmpty() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const createFn = useServerFn(createChat);
  const create = useMutation({
    mutationFn: () => createFn(),
    onSuccess: (c) => {
      qc.invalidateQueries({ queryKey: ["chats"] });
      navigate({ to: "/chat/$chatId", params: { chatId: c.id } });
    },
    onError: (e: Error) => toast.error(e.message),
  });
  return (
    <div className="h-full grid place-items-center p-8 text-center">
      <div className="max-w-md">
        <div className="mx-auto h-14 w-14 rounded-full bg-primary/10 grid place-items-center mb-4">
          <MessageSquare className="h-7 w-7 text-primary" />
        </div>
        <h2 className="text-2xl font-bold">Start a conversation</h2>
        <p className="text-muted-foreground mt-2">
          Ask me anything about programming, subjects, study tips, or career guidance.
        </p>
        <Button size="lg" className="mt-6 gap-2" onClick={() => create.mutate()} disabled={create.isPending}>
          <Plus className="h-4 w-4" /> New chat
        </Button>
      </div>
    </div>
  );
}