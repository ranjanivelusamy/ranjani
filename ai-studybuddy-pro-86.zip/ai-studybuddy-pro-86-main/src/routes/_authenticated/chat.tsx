import { createFileRoute, Outlet, useNavigate, Link, useRouterState } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listChats, createChat, deleteChat } from "@/lib/chats.functions";
import { Button } from "@/components/ui/button";
import { Plus, MessageSquare, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/chat")({
  component: ChatLayout,
  head: () => ({ meta: [{ title: "Chatbot — Smart Student Assistant" }] }),
});

function ChatLayout() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const listFn = useServerFn(listChats);
  const createFn = useServerFn(createChat);
  const delFn = useServerFn(deleteChat);

  const { data: chats } = useQuery({ queryKey: ["chats"], queryFn: () => listFn() });

  const create = useMutation({
    mutationFn: () => createFn(),
    onSuccess: (c) => {
      qc.invalidateQueries({ queryKey: ["chats"] });
      navigate({ to: "/chat/$chatId", params: { chatId: c.id } });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const del = useMutation({
    mutationFn: (chatId: string) => delFn({ data: { chatId } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["chats"] });
      navigate({ to: "/chat" });
    },
  });

  return (
    <div className="flex h-screen">
      <aside className="w-64 shrink-0 border-r bg-card hidden lg:flex flex-col">
        <div className="p-3 border-b">
          <Button className="w-full gap-2" onClick={() => create.mutate()} disabled={create.isPending}>
            <Plus className="h-4 w-4" /> New chat
          </Button>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {(chats ?? []).map((c) => {
            const active = pathname === `/chat/${c.id}`;
            return (
              <div
                key={c.id}
                className={`group flex items-center justify-between rounded-md px-2 py-1.5 text-sm ${
                  active ? "bg-primary/10 text-primary" : "hover:bg-secondary"
                }`}
              >
                <Link
                  to="/chat/$chatId"
                  params={{ chatId: c.id }}
                  className="flex items-center gap-2 min-w-0 flex-1"
                >
                  <MessageSquare className="h-3.5 w-3.5 shrink-0" />
                  <span className="truncate">{c.title}</span>
                </Link>
                <button
                  onClick={() => del.mutate(c.id)}
                  className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive"
                  aria-label="Delete chat"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            );
          })}
          {(chats ?? []).length === 0 && (
            <p className="text-xs text-muted-foreground px-2 py-4 text-center">No chats yet</p>
          )}
        </div>
      </aside>
      <div className="flex-1 min-w-0">
        <Outlet />
      </div>
    </div>
  );
}