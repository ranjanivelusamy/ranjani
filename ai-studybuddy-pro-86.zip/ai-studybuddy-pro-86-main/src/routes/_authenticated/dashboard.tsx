import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listChats, createChat } from "@/lib/chats.functions";
import { getProfile } from "@/lib/profile.functions";
import { Button } from "@/components/ui/button";
import { MessageSquare, Plus, GraduationCap, Sparkles } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: Dashboard,
  head: () => ({ meta: [{ title: "Dashboard — Smart Student Assistant" }] }),
});

function Dashboard() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const listFn = useServerFn(listChats);
  const createFn = useServerFn(createChat);
  const profileFn = useServerFn(getProfile);

  const { data: chats } = useQuery({ queryKey: ["chats"], queryFn: () => listFn() });
  const { data: profile } = useQuery({ queryKey: ["profile"], queryFn: () => profileFn() });

  const create = useMutation({
    mutationFn: () => createFn(),
    onSuccess: (c) => {
      qc.invalidateQueries({ queryKey: ["chats"] });
      navigate({ to: "/chat/$chatId", params: { chatId: c.id } });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <div className="text-sm text-muted-foreground flex items-center gap-1">
            <Sparkles className="h-3.5 w-3.5 text-primary" /> Welcome back
          </div>
          <h1 className="text-3xl font-bold">Hi, {profile?.full_name || "student"} 👋</h1>
          <p className="text-muted-foreground mt-1">Ready to learn something new today?</p>
        </div>
        <Button size="lg" className="gap-2" onClick={() => create.mutate()} disabled={create.isPending}>
          <Plus className="h-4 w-4" /> New chat
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Chats" value={chats?.length ?? 0} icon={MessageSquare} />
        <StatCard label="Course" value={profile?.course || "—"} icon={GraduationCap} />
        <StatCard label="Year" value={profile?.year || "—"} icon={Sparkles} />
      </div>

      <div>
        <h2 className="text-lg font-semibold mb-3">Recent chats</h2>
        <div className="rounded-xl border bg-card divide-y">
          {(chats ?? []).length === 0 && (
            <div className="p-8 text-center text-sm text-muted-foreground">
              No chats yet. Start your first conversation!
            </div>
          )}
          {(chats ?? []).map((c) => (
            <Link
              key={c.id}
              to="/chat/$chatId"
              params={{ chatId: c.id }}
              className="flex items-center justify-between px-4 py-3 hover:bg-secondary/60 transition"
            >
              <div className="flex items-center gap-3 min-w-0">
                <MessageSquare className="h-4 w-4 text-primary shrink-0" />
                <span className="truncate">{c.title}</span>
              </div>
              <span className="text-xs text-muted-foreground">
                {new Date(c.updated_at).toLocaleDateString()}
              </span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string | number;
  icon: React.ComponentType<{ className?: string }>;
}) {
  return (
    <div className="rounded-xl border bg-card p-5">
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">{label}</span>
        <Icon className="h-4 w-4 text-primary" />
      </div>
      <div className="text-2xl font-bold mt-2 truncate">{value}</div>
    </div>
  );
}