import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { generateText } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "./ai-gateway.server";

const SYSTEM_PROMPT = `You are the AI Smart Student Assistant, a friendly and knowledgeable helper for college students.
You help with:
- Programming doubts (explain code, debug, teach concepts across languages)
- Subject questions (math, science, engineering, humanities)
- Study guidance (planning, techniques, time management, exam prep)
- Career guidance (internships, resumes, interview prep, tech paths)

Guidelines:
- Be concise, encouraging, and clear. Use markdown, code blocks, and step-by-step explanations when helpful.
- If a question is ambiguous, ask a clarifying question.
- Never make up facts; if unsure, say so.`;

const Input = z.object({
  chatId: z.string().uuid(),
  message: z.string().min(1).max(4000),
});

export const sendChatMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => Input.parse(data))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    // Verify chat ownership
    const { data: chat, error: chatErr } = await supabase
      .from("chats")
      .select("id, title")
      .eq("id", data.chatId)
      .maybeSingle();
    if (chatErr || !chat) throw new Error("Chat not found");

    // Insert user message
    const { error: insertUserErr } = await supabase.from("messages").insert({
      chat_id: data.chatId,
      user_id: userId,
      role: "user",
      content: data.message,
    });
    if (insertUserErr) throw new Error(insertUserErr.message);

    // Load full history
    const { data: history, error: histErr } = await supabase
      .from("messages")
      .select("role, content")
      .eq("chat_id", data.chatId)
      .order("created_at", { ascending: true });
    if (histErr) throw new Error(histErr.message);

    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("AI service is not configured");

    const gateway = createLovableAiGatewayProvider(key);
    const model = gateway("google/gemini-3-flash-preview");

    let assistantText = "";
    try {
      const result = await generateText({
        model,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          ...(history ?? []).map((m) => ({
            role: m.role as "user" | "assistant" | "system",
            content: m.content,
          })),
        ],
      });
      assistantText = result.text?.trim() || "(no response)";
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes("429")) {
        throw new Error("Rate limit exceeded. Please wait a moment and try again.");
      }
      if (msg.includes("402")) {
        throw new Error("AI credits exhausted. Please add credits in Cloud settings.");
      }
      throw new Error("AI service error: " + msg);
    }

    // Save assistant message
    await supabase.from("messages").insert({
      chat_id: data.chatId,
      user_id: userId,
      role: "assistant",
      content: assistantText,
    });

    // If title is default, set it from first user message
    if (chat.title === "New chat") {
      await supabase
        .from("chats")
        .update({ title: data.message.slice(0, 60) })
        .eq("id", data.chatId);
    } else {
      await supabase.from("chats").update({ updated_at: new Date().toISOString() }).eq("id", data.chatId);
    }

    return { assistant: assistantText };
  });